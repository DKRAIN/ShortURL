#include "Redirect.h"

// Add definition of your processing function here
void Redirect::get(const HttpRequestPtr &req, std::function<void(const HttpResponsePtr &)> &&callback, int p1)
{
}
