#pragma once

#include <drogon/HttpSimpleController.h>
#include <Url.h>
using namespace drogon;
using Url=drogon_model::sqlite3::Url;
class Generate : public drogon::HttpSimpleController<Generate>
{
  std::set<std::string> TLDs;
  orm::Mapper<Url> mp{app().getFastDbClient()};
  public:
    void asyncHandleHttpRequest(const HttpRequestPtr& req, std::function<void (const HttpResponsePtr &)> &&callback) override;
    PATH_LIST_BEGIN
    // list path definitions here;
    PATH_ADD("/Generate", Get, Post);
    PATH_LIST_END
    Generate();
};
