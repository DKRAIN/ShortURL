#include "Generate.h"
#include "LUrlParser.h"
#include <fstream>
#include "Base62.h"
void Generate::asyncHandleHttpRequest(const HttpRequestPtr &req, std::function<void(const HttpResponsePtr &)> &&callback)
{
    // write your application logic here
    std::string longurl;
    if ((longurl = req->getParameter("url")).empty())
    {
        auto rjson = req->getJsonObject();
        if (rjson && (*rjson)["url"].isString())
        {
            longurl = (*rjson)["url"].asString();
        }
        else
        {
            Json::Value json;
            json["code"] = 400;
            json["message"] = "Bad Request";
            callback(HttpResponse::newHttpJsonResponse(json));
            return;
        }
    }
    if (longurl.size() > 1024)
    {
        Json::Value json;
        json["code"] = 400;
        json["message"] = "URL too long";
        callback(HttpResponse::newHttpJsonResponse(json));
        return;
    }
    auto url = LUrlParser::ParseURL::parseURL(longurl);
    if (!url.isValid() || (url.scheme_ != "http" && url.scheme_ != "https"))
    {
        Json::Value json;
        json["code"] = 100;
        json["message"] = "Unsupported scheme";
        callback(HttpResponse::newHttpJsonResponse(json));
        return;
    }
    auto pos = url.host_.find_last_of('.');
    if (pos == -1 || pos + 1 >= url.host_.size() || !TLDs.count(url.host_.substr(pos + 1, url.host_.size())))
    {
        Json::Value json;
        json["code"] = 300;
        json["message"] = "Unsupported TLD";
        callback(HttpResponse::newHttpJsonResponse(json));
        return;
    }
    Url sql;
    sql.setUrl(longurl);
    mp.insert(
        sql, [callback](const Url &dat) {
            Json::Value json;
    json["code"] = 0;
    json["short"] = Base62::encode(*dat.getId());
    callback(HttpResponse::newHttpJsonResponse(json));
        }, [callback](const orm::DrogonDbException &)
        {Json::Value json;
    json["code"] = 500;
    json["message"] = "Server Error";
    callback(HttpResponse::newHttpJsonResponse(json)); });
}

Generate::Generate()
{
    std::ifstream ifs("tld.list");
    std::string tmp;
    while (ifs >> tmp)
    {
        TLDs.insert(tmp);
    }
}